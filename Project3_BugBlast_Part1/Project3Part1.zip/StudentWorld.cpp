#include "StudentWorld.h"

GameWorld* createStudentWorld()
{
	return new StudentWorld();
}
